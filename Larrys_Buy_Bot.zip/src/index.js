require("dotenv").config();

const WebSocket = require("ws");

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const PUMPPORTAL_API_KEY = process.env.PUMPPORTAL_API_KEY;
const DEFAULT_MINT = (process.env.TRACKED_MINT || "").trim();
const MIN_BUY_SOL = Number(process.env.MIN_BUY_SOL || 0);
const SHOW_SELLS = String(process.env.SHOW_SELLS || "false").toLowerCase() === "true";
const BOT_NAME = process.env.BOT_NAME || "Larry's Buy Bot";

if (!BOT_TOKEN) {
  console.error("Missing TELEGRAM_BOT_TOKEN in .env");
  process.exit(1);
}
if (!PUMPPORTAL_API_KEY) {
  console.error("Missing PUMPPORTAL_API_KEY in .env");
  process.exit(1);
}

const TELEGRAM = `https://api.telegram.org/bot${BOT_TOKEN}`;
const tracked = new Map(); // chatId -> mint
const sockets = new Map(); // mint -> websocket
const seenTrades = new Set();
let updateOffset = 0;

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function tg(method, body = {}) {
  const res = await fetch(`${TELEGRAM}/${method}`, {
    method: "POST",
    headers: {"content-type": "application/json"},
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (!data.ok) throw new Error(`${method}: ${data.description || "Telegram API error"}`);
  return data.result;
}

function shortWallet(w) {
  if (!w || w.length < 10) return w || "unknown";
  return `${w.slice(0, 4)}...${w.slice(-4)}`;
}

function fmtSol(n) {
  const x = Number(n);
  if (!Number.isFinite(x)) return "0";
  if (x >= 100) return x.toFixed(1);
  if (x >= 10) return x.toFixed(2);
  if (x >= 1) return x.toFixed(3);
  return x.toFixed(4);
}

function fmtMc(marketCapSol) {
  const x = Number(marketCapSol);
  if (!Number.isFinite(x) || x <= 0) return "N/A";
  if (x >= 1000000) return `${(x / 1000000).toFixed(2)}M SOL`;
  if (x >= 1000) return `${(x / 1000).toFixed(1)}K SOL`;
  return `${x.toFixed(0)} SOL`;
}

function mintLink(mint) {
  return `https://pump.fun/coin/${mint}`;
}

async function sendBuy(chatId, trade) {
  const sol = Number(trade.solAmount || 0);
  if (sol < MIN_BUY_SOL) return;
  if (trade.txType !== "buy") return;

  const symbol = trade.symbol || trade.name || "TOKEN";
  const buyer = trade.user || trade.owner || trade.buyer;
  const mc = fmtMc(trade.marketCapSol);

  const text =
`🟢 <b>${BOT_NAME}</b>

🟢 <b>BUY DETECTED</b>
🪙 <b>$${escapeHtml(symbol)}</b>
💰 <b>${fmtSol(sol)} SOL</b>
📊 MC: <b>${mc}</b>
👛 Buyer: <code>${escapeHtml(shortWallet(buyer))}</code>

<a href="${mintLink(trade.mint)}">View token on Pump.fun</a>`;

  await tg("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true
  });
}

function escapeHtml(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

async function notifyAll(mint, trade) {
  for (const [chatId, chatMint] of tracked.entries()) {
    if (chatMint === mint) {
      try {
        if (trade.txType === "buy") await sendBuy(chatId, trade);
        else if (SHOW_SELLS && trade.txType === "sell") {
          await tg("sendMessage", {
            chat_id: chatId,
            text: `🔴 <b>${BOT_NAME}</b>\n\nSELL: <b>${fmtSol(Number(trade.solAmount || 0))} SOL</b>\n👛 <code>${escapeHtml(shortWallet(trade.user || trade.owner))}</code>`,
            parse_mode: "HTML"
          });
        }
      } catch (e) {
        console.error("Telegram send error:", e.message);
      }
    }
  }
}

function subscribeMint(mint) {
  if (sockets.has(mint)) return;

  const uri = `wss://pumpportal.fun/api/data?api-key=${encodeURIComponent(PUMPPORTAL_API_KEY)}`;
  const ws = new WebSocket(uri);
  sockets.set(mint, ws);

  ws.on("open", () => {
    console.log(`Watching ${mint}`);
    ws.send(JSON.stringify({
      method: "subscribeTokenTrade",
      keys: [mint]
    }));
  });

  ws.on("message", async raw => {
    try {
      const trade = JSON.parse(raw.toString());
      if (!trade || trade.mint !== mint) return;

      const unique = [
        trade.signature,
        trade.txHash,
        trade.traderPublicKey,
        trade.user,
        trade.solAmount,
        trade.timestamp
      ].filter(Boolean).join(":");

      if (unique && seenTrades.has(unique)) return;
      if (unique) {
        seenTrades.add(unique);
        if (seenTrades.size > 5000) {
          const first = seenTrades.values().next().value;
          seenTrades.delete(first);
        }
      }

      await notifyAll(mint, trade);
    } catch (e) {
      console.error("Trade parse error:", e.message);
    }
  });

  ws.on("error", err => console.error(`PumpPortal WS error (${mint}):`, err.message));

  ws.on("close", () => {
    sockets.delete(mint);
    console.log(`Disconnected from ${mint}; reconnecting in 5s...`);
    setTimeout(() => {
      if ([...tracked.values()].includes(mint)) subscribeMint(mint);
    }, 5000);
  });
}

function validateMint(mint) {
  return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(mint);
}

async function isAdmin(chatId, userId) {
  const member = await tg("getChatMember", { chat_id: chatId, user_id: userId });
  return ["creator", "administrator"].includes(member.status);
}

async function handleMessage(msg) {
  if (!msg.text || !msg.chat) return;

  const chatId = msg.chat.id;
  const userId = msg.from?.id;
  const parts = msg.text.trim().split(/\s+/);
  const command = (parts[0] || "").split("@")[0].toLowerCase();

  if (command === "/start" || command === "/help") {
    await tg("sendMessage", {
      chat_id: chatId,
      text:
`🤖 <b>${BOT_NAME}</b>

I track Pump.fun buys and post alerts here.

<b>Commands</b>
/track &lt;token_CA&gt; — track a token
/untrack — stop tracking this chat
/status — show the current token
/help — show this help

Only group admins can change the tracked token.`,
      parse_mode: "HTML"
    });
    return;
  }

  if (command === "/status") {
    const mint = tracked.get(chatId) || DEFAULT_MINT || "None";
    await tg("sendMessage", {
      chat_id: chatId,
      text: `📡 <b>${BOT_NAME}</b>\n\nTracking:\n<code>${escapeHtml(mint)}</code>`,
      parse_mode: "HTML"
    });
    return;
  }

  if (command === "/track") {
    if (!userId || !(await isAdmin(chatId, userId))) {
      await tg("sendMessage", { chat_id: chatId, text: "Only group admins can use /track." });
      return;
    }

    const mint = parts[1];
    if (!mint || !validateMint(mint)) {
      await tg("sendMessage", {
        chat_id: chatId,
        text: "Usage: /track <token_CA>\n\nPaste the full Solana token contract address."
      });
      return;
    }

    tracked.set(chatId, mint);
    subscribeMint(mint);

    await tg("sendMessage", {
      chat_id: chatId,
      text: `✅ <b>${BOT_NAME}</b> is now tracking:\n<code>${escapeHtml(mint)}</code>\n\nBuy alerts will appear here.`,
      parse_mode: "HTML"
    });
    return;
  }

  if (command === "/untrack") {
    if (!userId || !(await isAdmin(chatId, userId))) {
      await tg("sendMessage", { chat_id: chatId, text: "Only group admins can use /untrack." });
      return;
    }
    tracked.delete(chatId);
    await tg("sendMessage", { chat_id: chatId, text: `🛑 ${BOT_NAME} stopped tracking this chat.` });
  }
}

async function pollTelegram() {
  while (true) {
    try {
      const updates = await tg("getUpdates", {
        offset: updateOffset,
        timeout: 25,
        allowed_updates: ["message"]
      });

      for (const u of updates) {
        updateOffset = u.update_id + 1;
        try {
          await handleMessage(u.message);
        } catch (e) {
          console.error("Message handler error:", e.message);
        }
      }
    } catch (e) {
      console.error("Telegram polling error:", e.message);
      await sleep(3000);
    }
  }
}

(async () => {
  const me = await tg("getMe");
  console.log(`Started @${me.username}`);

  if (DEFAULT_MINT && validateMint(DEFAULT_MINT)) {
    // Default tracking works for direct deployment/testing; group /track remains available.
    subscribeMint(DEFAULT_MINT);
  }

  await pollTelegram();
})();