# Larry's Buy Bot

A Telegram **buy-tracker** for Pump.fun tokens.

It does NOT buy or sell tokens. It listens for Pump.fun trade events and posts buy alerts to a Telegram group.

## What it does

- Tracks one Pump.fun token per Telegram chat.
- Group admins can use `/track <CA>`.
- Posts buy amount in SOL.
- Shows buyer wallet in shortened form.
- Shows market-cap data when supplied by the feed.
- Includes a Pump.fun token link.
- Automatically reconnects the data WebSocket.
- `/status`, `/untrack`, `/help`.

## Requirements

- Node.js 18+
- A Telegram bot token from BotFather.
- A PumpPortal API key for the trade WebSocket.
- A server/VPS that stays online.

## Setup

1. Copy `.env.example` to `.env`.
2. Put your Telegram bot token in `TELEGRAM_BOT_TOKEN`.
3. Put your PumpPortal API key in `PUMPPORTAL_API_KEY`.
4. Run:

```bash
npm install
npm start
```

5. Add the bot to your Telegram group.
6. Give it permission to send messages.
7. In the group, an admin sends:

```text
/track YOUR_TOKEN_CONTRACT_ADDRESS
```

The bot will then post buy alerts for that token.

## Bot commands

```text
/start
/help
/track <CA>
/untrack
/status
```

## Profile picture

`larrys_buy_bot_avatar.jpg` is the image supplied for the bot profile. Upload it to BotFather when setting the bot's profile picture.

## Important

The PumpPortal token-trade stream is metered. Check the provider's current pricing before running it continuously.

Never put your Telegram bot token or API key directly into the source code or share them publicly.
