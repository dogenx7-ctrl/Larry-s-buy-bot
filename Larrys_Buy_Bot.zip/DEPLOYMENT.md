# Quick deployment

## Render / Railway / VPS

Use a Node.js service and set these environment variables:

- `TELEGRAM_BOT_TOKEN`
- `PUMPPORTAL_API_KEY`
- `TRACKED_MINT` (optional)
- `MIN_BUY_SOL` (optional, e.g. `0.25`)
- `SHOW_SELLS` (optional, `false`)

Start command:

```bash
npm start
```

For a Telegram group bot, add the bot to the group and use `/track <CA>` as an administrator.

## Local test

```bash
npm install
cp .env.example .env
npm start
```

Keep the terminal open while testing.
